<template>
  <MainComponent></MainComponent>
</template>

<script>
import MainComponent from './components/MainComponent.vue'


export default {
  name: 'App',
  components: {
    MainComponent
  }
}
</script>

